# VynPhone Owner Panel v0.2

Android project with a first-pass Owner Panel UI:
- invite-code display/generator (local demo only)
- selectable per-account CloudPhone limit from 1 to 5
- five CloudPhone status rows
- GitHub Actions workflow to build a debug APK

IMPORTANT: This is only the Android UI prototype. Invite codes are not yet validated by a server, account permissions are not secured, and CloudPhone rows do not launch real Android 15 virtual devices. Persistent cloud Android hosting and remote screen/input streaming still need a compatible server and backend.
