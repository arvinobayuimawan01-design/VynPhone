package com.vynphone.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.security.SecureRandom;

public class MainActivity extends Activity {
    LinearLayout page;
    TextView inviteValue, countLabel;
    int phoneCount = 1;
    final String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,12,28));
        getWindow().setNavigationBarColor(Color.rgb(7,12,28));
        getWindow().getDecorView().setSystemUiVisibility(0);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(7,12,28));
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(page);
        setContentView(scroll);

        addText("VynPhone", 30, Color.WHITE, true);
        addText("OWNER CONTROL PANEL", 12, Color.rgb(75,180,255), true);
        addSpace(22);
        cardTitle("Akun & Undangan");
        addText("Kode undangan hanya contoh tampilan. Penguncian akses perlu backend aktif.", 13, Color.LTGRAY, false);
        inviteValue = addText("— BELUM DIBUAT —", 20, Color.WHITE, true);
        Button make = button("BUAT KODE UNDANGAN");
        make.setOnClickListener(v -> {
            inviteValue.setText(makeCode());
        });
        page.addView(make);
        addSpace(18);

        cardTitle("Batas CloudPhone");
        addText("Maksimal perangkat per akun", 14, Color.LTGRAY, false);
        countLabel = addText("1 CloudPhone", 22, Color.WHITE, true);
        SeekBar seek = new SeekBar(this);
        seek.setMax(4);
        seek.setProgress(0);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(45,150,255)));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.rgb(45,150,255)));
        page.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                phoneCount = p + 1;
                countLabel.setText(phoneCount + " CloudPhone" + (phoneCount > 1 ? "s" : ""));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        addSpace(18);

        cardTitle("Daftar CloudPhone");
        for (int i=1; i<=5; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            row.setBackground(round(Color.rgb(20,30,52), 14));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(8);
            page.addView(row, lp);
            TextView name = new TextView(this);
            name.setText("CloudPhone " + i + "\\nBelum terhubung");
            name.setTextColor(Color.WHITE);
            name.setTextSize(14);
            name.setLineSpacing(dp(2), 1f);
            row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            TextView state = new TextView(this);
            state.setText(i == 1 ? "OFFLINE" : "TERKUNCI");
            state.setTextColor(i == 1 ? Color.rgb(255,190,80) : Color.GRAY);
            state.setTextSize(10);
            state.setTypeface(null, Typeface.BOLD);
            row.addView(state);
        }
        addSpace(12);
        TextView note = addText("STATUS SERVER: BELUM TERHUBUNG\\nTombol mulai CloudPhone belum aktif sampai server Android virtual tersedia. Aplikasi ini belum menyediakan Android 15 jarak jauh.", 12, Color.rgb(255,195,105), false);
        note.setLineSpacing(dp(4), 1f);
    }

    TextView addText(String t, int size, int color, boolean bold) {
        TextView x = new TextView(this);
        x.setText(t); x.setTextSize(size); x.setTextColor(color);
        if (bold) x.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(7); page.addView(x, p); return x;
    }
    void cardTitle(String t) {
        TextView x = addText(t, 18, Color.WHITE, true);
        x.setPadding(0, dp(5), 0, dp(5));
    }
    void addSpace(int h) { View v = new View(this); page.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    Button button(String t) {
        Button b = new Button(this); b.setText(t); b.setTextColor(Color.WHITE);
        b.setBackground(round(Color.rgb(30,115,220), 12));
        page.addView(b, new LinearLayout.LayoutParams(-1, dp(52))); return b;
    }
    android.graphics.drawable.GradientDrawable round(int c, int r) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(c); d.setCornerRadius(dp(r)); return d;
    }
    String makeCode() {
        SecureRandom random = new SecureRandom();
        StringBuilder s = new StringBuilder("VYN-");
        for (int i=0;i<8;i++) s.append(chars.charAt(random.nextInt(chars.length())));
        return s.toString();
    }
}