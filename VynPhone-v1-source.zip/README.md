# VynPhone v1.0 — Android client prototype

This is the first Android client scaffold for VynPhone.

## Important status
- This project is a client UI prototype, NOT a working cloud phone yet.
- Start / Reconnect / Remote Screen are placeholders until a real backend and Android host are deployed.
- Android 15, 6 GB RAM and 64 GB storage are target settings for the remote virtual device; they are not allocated by this APK.
- No cloud server is included and no free 24/7 Android host is provisioned.

## Build APK using GitHub Actions from a phone
1. Create a GitHub account if you do not already have one.
2. Create a new public or private repository named `VynPhone`.
3. Upload the contents of this ZIP into the repository root (not the ZIP as a single file).
4. Open the repository's **Actions** tab.
5. Select **Build VynPhone APK** and tap **Run workflow** (or wait for the first push build).
6. Open the completed workflow run, scroll to **Artifacts**, and download `VynPhone-debug-apk`.
7. Extract the artifact ZIP; install `app-debug.apk` on your Android phone.

## Next engineering milestone
Provision a compatible Linux host with Android virtualization support (Binder/BinderFS and suitable graphics support), then implement authenticated API endpoints and WebRTC streaming. Do not expose an unauthenticated Android control port to the public internet.
