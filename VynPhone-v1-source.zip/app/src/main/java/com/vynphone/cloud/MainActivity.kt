package com.vynphone.cloud

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1C2A3D)
private val Blue = Color(0xFF3478F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VynPhoneApp() }
    }
}

@Composable
fun VynPhoneApp() {
    var status by remember { mutableStateOf("Belum terhubung") }
    var message by remember { mutableStateOf("Server belum dikonfigurasi") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Navy, surface = Panel
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Column(
                modifier = Modifier.fillMaxSize().padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Cloud, null, tint = Color(0xFF72B7FF),
                        modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("VynPhone", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("YOUR ANDROID IN THE CLOUD", color = Color.LightGray, fontSize = 10.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("MY CLOUDPHONE", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            AssistChip(onClick = {}, label = { Text(status) })
                        }
                        Text("Android 15", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("RAM virtual: 6 GB  •  Storage: 64 GB",
                            color = Color.LightGray, fontSize = 13.sp)
                        Text(message, color = Color(0xFFFFD180), fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = { message = "Belum bisa dimulai: backend server belum tersedia." },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("START CLOUDPHONE", fontWeight = FontWeight.Bold) }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { message = "Reconnect tersedia setelah server terhubung." },
                        modifier = Modifier.weight(1f)) { Text("Reconnect") }
                    OutlinedButton(onClick = { message = "Remote Screen menunggu koneksi server." },
                        modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Monitor, null)
                        Spacer(Modifier.width(5.dp))
                        Text("Remote Screen")
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, null, tint = Color.LightGray)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Cloud Settings", fontWeight = FontWeight.SemiBold)
                            Text("Server URL belum diatur", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("VynPhone v1.0 • Prototype client",
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
